static int topbar = 0;                        /* bottom bar */
static int centered = 1;                      /* centered patch */
static unsigned int border_width = 2;         /* border patch */
static unsigned int lineheight = 28;          /* lineheight patch */
static unsigned int min_lineheight = 28;
static int min_width = 600;                   /* width when centered */



/* Fonts */
static const char *fonts[] = {
    "IosevkaTerm Nerd Font Mono:size=11:antialias=true:autohint=true"
};

/* Optional prompt */
static const char *prompt = "  ";           /* subtle search icon */

/* Rose + Plum color scheme matching dwm/picom */
static const char *colors[SchemeLast][2] = {
    /*               fg          bg          */
    [SchemeNorm] = { "#b197a8", "#1a171d" },  /* dusty rose on deep charcoal */
    [SchemeSel]  = { "#1a171d", "#7b5a9e" },  /* dark fg on plum */
    [SchemeOut]  = { "#1a171d", "#b88ea3" },  /* dark fg on soft rose */
};

static const unsigned int alpha[SchemeLast][2] = {
    [SchemeNorm] = { 0xff, 0xcc },
    [SchemeSel]  = { 0xff, 0xcc },
};

static unsigned int lines = 8;
static const char worddelimiters[] = " /?\"&[]";
